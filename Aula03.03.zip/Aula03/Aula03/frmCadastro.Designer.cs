﻿namespace Aula03
{
    partial class frmCadastro
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCadastro));
            this.label1 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtLogradouro = new System.Windows.Forms.TextBox();
            this.dtpDataNascimento = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBairro = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtCidade = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtObservacao = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.btoExcluir = new System.Windows.Forms.Button();
            this.btoLimpar = new System.Windows.Forms.Button();
            this.btoSair = new System.Windows.Forms.Button();
            this.btoPesquisar = new System.Windows.Forms.Button();
            this.btoCadastrar = new System.Windows.Forms.Button();
            this.btoAlterar = new System.Windows.Forms.Button();
            this.cboStatus = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cboUF = new System.Windows.Forms.ComboBox();
            this.cboEstadoCivil = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtCpf = new System.Windows.Forms.MaskedTextBox();
            this.txtCep = new System.Windows.Forms.MaskedTextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtDataCadastro = new System.Windows.Forms.TextBox();
            this.txtNumero = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.cboGenero = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.txtNumero)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // txtNome
            // 
            resources.ApplyResources(this.txtNome, "txtNome");
            this.txtNome.Name = "txtNome";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.Gold;
            this.label4.Name = "label4";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // txtLogradouro
            // 
            resources.ApplyResources(this.txtLogradouro, "txtLogradouro");
            this.txtLogradouro.Name = "txtLogradouro";
            // 
            // dtpDataNascimento
            // 
            resources.ApplyResources(this.dtpDataNascimento, "dtpDataNascimento");
            this.dtpDataNascimento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDataNascimento.Name = "dtpDataNascimento";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // txtBairro
            // 
            resources.ApplyResources(this.txtBairro, "txtBairro");
            this.txtBairro.Name = "txtBairro";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // txtCidade
            // 
            resources.ApplyResources(this.txtCidade, "txtCidade");
            this.txtCidade.Name = "txtCidade";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // txtObservacao
            // 
            resources.ApplyResources(this.txtObservacao, "txtObservacao");
            this.txtObservacao.Name = "txtObservacao";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // txtID
            // 
            resources.ApplyResources(this.txtID, "txtID");
            this.txtID.Name = "txtID";
            // 
            // btoExcluir
            // 
            resources.ApplyResources(this.btoExcluir, "btoExcluir");
            this.btoExcluir.Name = "btoExcluir";
            this.btoExcluir.UseVisualStyleBackColor = true;
            this.btoExcluir.Click += new System.EventHandler(this.btoExcluir_Click);
            // 
            // btoLimpar
            // 
            resources.ApplyResources(this.btoLimpar, "btoLimpar");
            this.btoLimpar.Name = "btoLimpar";
            this.btoLimpar.UseVisualStyleBackColor = true;
            this.btoLimpar.Click += new System.EventHandler(this.btoLimpar_Click);
            // 
            // btoSair
            // 
            resources.ApplyResources(this.btoSair, "btoSair");
            this.btoSair.Name = "btoSair";
            this.btoSair.UseVisualStyleBackColor = true;
            this.btoSair.Click += new System.EventHandler(this.btoSair_Click);
            // 
            // btoPesquisar
            // 
            resources.ApplyResources(this.btoPesquisar, "btoPesquisar");
            this.btoPesquisar.Name = "btoPesquisar";
            this.btoPesquisar.UseVisualStyleBackColor = true;
            // 
            // btoCadastrar
            // 
            resources.ApplyResources(this.btoCadastrar, "btoCadastrar");
            this.btoCadastrar.Name = "btoCadastrar";
            this.btoCadastrar.UseVisualStyleBackColor = true;
            this.btoCadastrar.Click += new System.EventHandler(this.btoCadastrar_Click);
            // 
            // btoAlterar
            // 
            resources.ApplyResources(this.btoAlterar, "btoAlterar");
            this.btoAlterar.Name = "btoAlterar";
            this.btoAlterar.UseVisualStyleBackColor = true;
            this.btoAlterar.Click += new System.EventHandler(this.btoAlterar_Click);
            // 
            // cboStatus
            // 
            resources.ApplyResources(this.cboStatus, "cboStatus");
            this.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboStatus.FormattingEnabled = true;
            this.cboStatus.Items.AddRange(new object[] {
            resources.GetString("cboStatus.Items"),
            resources.GetString("cboStatus.Items1")});
            this.cboStatus.Name = "cboStatus";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // cboUF
            // 
            resources.ApplyResources(this.cboUF, "cboUF");
            this.cboUF.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboUF.FormattingEnabled = true;
            this.cboUF.Items.AddRange(new object[] {
            resources.GetString("cboUF.Items"),
            resources.GetString("cboUF.Items1"),
            resources.GetString("cboUF.Items2"),
            resources.GetString("cboUF.Items3"),
            resources.GetString("cboUF.Items4"),
            resources.GetString("cboUF.Items5"),
            resources.GetString("cboUF.Items6"),
            resources.GetString("cboUF.Items7"),
            resources.GetString("cboUF.Items8"),
            resources.GetString("cboUF.Items9"),
            resources.GetString("cboUF.Items10"),
            resources.GetString("cboUF.Items11"),
            resources.GetString("cboUF.Items12"),
            resources.GetString("cboUF.Items13"),
            resources.GetString("cboUF.Items14"),
            resources.GetString("cboUF.Items15"),
            resources.GetString("cboUF.Items16"),
            resources.GetString("cboUF.Items17"),
            resources.GetString("cboUF.Items18"),
            resources.GetString("cboUF.Items19"),
            resources.GetString("cboUF.Items20"),
            resources.GetString("cboUF.Items21"),
            resources.GetString("cboUF.Items22"),
            resources.GetString("cboUF.Items23"),
            resources.GetString("cboUF.Items24"),
            resources.GetString("cboUF.Items25"),
            resources.GetString("cboUF.Items26")});
            this.cboUF.Name = "cboUF";
            // 
            // cboEstadoCivil
            // 
            resources.ApplyResources(this.cboEstadoCivil, "cboEstadoCivil");
            this.cboEstadoCivil.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEstadoCivil.FormattingEnabled = true;
            this.cboEstadoCivil.Items.AddRange(new object[] {
            resources.GetString("cboEstadoCivil.Items"),
            resources.GetString("cboEstadoCivil.Items1"),
            resources.GetString("cboEstadoCivil.Items2")});
            this.cboEstadoCivil.Name = "cboEstadoCivil";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // txtCpf
            // 
            resources.ApplyResources(this.txtCpf, "txtCpf");
            this.txtCpf.Name = "txtCpf";
            // 
            // txtCep
            // 
            resources.ApplyResources(this.txtCep, "txtCep");
            this.txtCep.Name = "txtCep";
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            // 
            // txtDataCadastro
            // 
            resources.ApplyResources(this.txtDataCadastro, "txtDataCadastro");
            this.txtDataCadastro.Name = "txtDataCadastro";
            this.txtDataCadastro.ReadOnly = true;
            // 
            // txtNumero
            // 
            resources.ApplyResources(this.txtNumero, "txtNumero");
            this.txtNumero.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.txtNumero.Name = "txtNumero";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // cboGenero
            // 
            resources.ApplyResources(this.cboGenero, "cboGenero");
            this.cboGenero.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGenero.FormattingEnabled = true;
            this.cboGenero.Items.AddRange(new object[] {
            resources.GetString("cboGenero.Items"),
            resources.GetString("cboGenero.Items1"),
            resources.GetString("cboGenero.Items2"),
            resources.GetString("cboGenero.Items3"),
            resources.GetString("cboGenero.Items4")});
            this.cboGenero.Name = "cboGenero";
            // 
            // frmCadastro
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.CancelButton = this.btoSair;
            this.Controls.Add(this.cboStatus);
            this.Controls.Add(this.cboEstadoCivil);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.cboGenero);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtNumero);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtDataCadastro);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtCep);
            this.Controls.Add(this.txtCpf);
            this.Controls.Add(this.cboUF);
            this.Controls.Add(this.btoAlterar);
            this.Controls.Add(this.btoSair);
            this.Controls.Add(this.btoCadastrar);
            this.Controls.Add(this.btoPesquisar);
            this.Controls.Add(this.btoLimpar);
            this.Controls.Add(this.btoExcluir);
            this.Controls.Add(this.dtpDataNascimento);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtObservacao);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.txtCidade);
            this.Controls.Add(this.txtBairro);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtLogradouro);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Name = "frmCadastro";
            this.Load += new System.EventHandler(this.frmCadastro_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtNumero)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private TextBox txtNome;
        private Label label2;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox txtLogradouro;
        private DateTimePicker dtpDataNascimento;
        private Label label7;
        private Label label8;
        private TextBox txtBairro;
        private Label label9;
        private Label label10;
        private TextBox txtCidade;
        private Label label11;
        private Label label12;
        private TextBox txtObservacao;
        private Label label13;
        private TextBox txtID;
        private Button btoExcluir;
        private Button btoLimpar;
        private Button btoSair;
        private Button btoPesquisar;
        private Button btoCadastrar;
        private Button btoAlterar;
        private Label label14;
        private ComboBox cboUF;
        private Label label15;
        private MaskedTextBox txtCpf;
        private MaskedTextBox txtCep;
        private ComboBox cboStatus;
        private ComboBox cboEstadoCivil;
        private Label label16;
        private TextBox txtDataCadastro;
        private NumericUpDown txtNumero;
        private Label label3;
        private ComboBox cboGenero;
    }
}